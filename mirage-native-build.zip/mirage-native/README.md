# Mirage: сборка приложения для Android и iPhone

Это обёртка (Capacitor) вокруг твоего приложения из папки `www`. Из неё получаются настоящие приложения для Google Play и App Store.

## Что нужно
- Компьютер с Node.js (nodejs.org).
- Для Android: Android Studio. Аккаунт разработчика Google Play (разовый платёж 25 $).
- Для iPhone: Mac с Xcode. Аккаунт Apple Developer (99 $ в год). Без Mac можно использовать облачную сборку (например, Codemagic или Expo EAS).

## Шаги
1. Открой терминал в этой папке и выполни `npm install`.
2. Поменяй `appId` в `capacitor.config.json` на свой уникальный (например, `kz.tvoyenazvanie.mirage`). Потом его уже нельзя менять в сторе.
3. Android: `npx cap add android`, затем `npm run icons`, затем `npx cap sync` и `npm run android`. В Android Studio выбери Build, Generate Signed Bundle, и загрузи файл в Google Play Console.
4. iPhone: `npx cap add ios`, `npm run icons`, `npx cap sync`, `npm run ios`, затем Product, Archive в Xcode и загрузка в App Store Connect.
5. Когда меняешь файлы в `www`, каждый раз запускай `npx cap sync`.

## Важное для публикации
- В описании приложения честно напиши, что это развлечение и баланс вымышленный. Тег «Демо» в интерфейсе оставь, он помогает пройти проверку.
- Apple и Google могут отклонить приложение, если оно похоже на настоящий банк или кошелёк. Не используй логотипы и названия реальных банков и бирж.
- Подписку в приложении нужно принимать через их встроенные покупки (Apple In-App Purchase, Google Play Billing), комиссия 15–30 %. Для этого обычно подключают сервис RevenueCat.
- Apple может отклонить «просто сайт в обёртке». Добавь реально нативные вещи (уведомления, виджет, шаринг карточки, Face ID).
